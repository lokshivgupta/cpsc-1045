let canvas = document.getElementById("myCanvas");
let ctx = canvas.getContext("2d");

const width = 800;
const height = 500;
const MID = width / 2;
const GROUND = 400;

ctx.fillStyle = "cyan";
ctx.fillRect(0, 0, width, height); //sky background

ctx.fillStyle = "lightyellow";
ctx.fillRect(0, GROUND, width, 100); // ground

ctx.fillStyle = "yellow";
ctx.beginPath();
ctx.arc(width+10, -10, 80, 0, 2 * Math.PI); //sun
ctx.fill();

ctx.fillStyle = "greenyellow";
ctx.beginPath();
ctx.arc(MID, GROUND - 150, 150, Math.PI, 2 * Math.PI); // umbrella
ctx.fill();

ctx.beginPath();
ctx.fillStyle = "darkgray";
ctx.fillRect(MID, GROUND-150, 10, 200); // umbrella pole
ctx.fill();

